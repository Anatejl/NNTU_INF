#include "4a-header.h"

int main() {

    char s1[100], s2[100];
    do_input(s1, s2);
    do_process(s1, s2);
    do_output(s1);

    return 0;
}

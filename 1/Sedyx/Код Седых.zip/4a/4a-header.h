#ifndef STRING_UTILS_H
#define STRING_UTILS_H

#include <stdio.h>
#include <string.h>

void do_input(char s1[], char s2[]);
void do_process(char s1[], char s2[]);
void do_output(char s1[]);

#endif // STRING_UTILS_H

#include <stdio.h>

void do_output(char s1[]) {

    printf("Processed string (s1): %s\n", s1);
    
}
#include "4p-header.h"

void do_output(char *source_string) {

    printf("Processed string: %s\n", source_string);
    
}
#ifndef STRING_UTILS_H
#define STRING_UTILS_H

#include <stdio.h>
#include <string.h>

void do_input(char *source_string, char *remove_string);
void do_process(char *source_string, char *remove_string);
void do_output(char *source_string);

#endif // STRING_UTILS_H

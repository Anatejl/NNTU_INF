#include "5-pointer-header.h"

int main(){

    Company company;

    int ret = do_run(&company);

    return ret;
}
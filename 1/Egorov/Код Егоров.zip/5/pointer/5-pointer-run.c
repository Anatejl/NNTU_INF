#include "5-pointer-header.h"

int do_run(Company* company){

    do_input(company);
    do_process(company);
    do_output(company);

    return 0;

}
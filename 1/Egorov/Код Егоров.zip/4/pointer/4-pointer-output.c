#include <stdio.h>
#include "4-functions.h"

void do_output(const char *str) {

    printf("Reversed string: %s\n", str);
    
}

#ifndef FUNCTIONS_H
#define FUNCTIONS_H

void get_input(char *str, int length);
void process(char *str);
void do_output(const char *str);

#endif
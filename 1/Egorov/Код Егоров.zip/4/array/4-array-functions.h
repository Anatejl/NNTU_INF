#ifndef FUNCTIONS_H
#define FUNCTIONS_H

#include <string.h>
#include <stdio.h>

void get_input(char str[81]);
void do_process(char str[81]);
void do_output(char str[81]);

#endif

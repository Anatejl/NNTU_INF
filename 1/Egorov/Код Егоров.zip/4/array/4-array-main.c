#include "4-array-functions.h"

int main() {

    char str[81]; 

    get_input(str);
    do_process(str);
    do_output(str);
    
    return 0;
}

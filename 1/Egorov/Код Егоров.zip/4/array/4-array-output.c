#include "4-array-functions.h"

void do_output(char str[81]) {

    printf("Reversed string: %s\n", str);
    
}

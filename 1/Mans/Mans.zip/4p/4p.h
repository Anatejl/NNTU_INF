// VAR 7

#include <stdio.h>

void matrix_init(int *matrix, int size);
void matrix_transpose(int *matrix, int *transposed, int size);
void matrix_print(int *matrix, int size);

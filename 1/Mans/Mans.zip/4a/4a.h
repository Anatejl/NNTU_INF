// VAR 7

#include <stdio.h>

#define SIZE 6

void matrix_init(int matrix[SIZE][SIZE]);
void matrix_transpose(int matrix[SIZE][SIZE], int transposed[SIZE][SIZE]);
void matrix_print(int matrix[SIZE][SIZE]);
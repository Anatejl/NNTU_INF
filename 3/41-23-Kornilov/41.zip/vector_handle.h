#include <vector>

std::vector<int>vector_fill(int n);
int vector_count_positive(std::vector<int>to_compute);
int vector_count_negative(std::vector<int>to_compute);
int vector_count_zeroes(std::vector<int>to_compute);
void vector_show(std::vector<int>to_compute);